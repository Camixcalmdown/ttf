import string
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
import requests
import time
import random
import datetime
from fake_useragent import UserAgent
from datetime import datetime
import platform
import socket
import colorama
import os
import base64
import itertools
from threading import Thread
import socket
green = colorama.Fore.LIGHTGREEN_EX
red = colorama.Fore.RED
def clear():
    os.system("clear" if os.name == "nt" else "cls")
clear()
device_name = socket.gethostname()
r = requests.get("https://pastebin.com/u3syD3F2")
if str(device_name) in r.text:
    current_time = datetime.now()
    login = input(green + "[?] Введите ваш логин -> ")
    password = input(green + "[?] Введите ваш пароль -> ")
    account = str(login) + str(password) + str(device_name)
    print(green + "\n[!] Ваш логин -> ",login)
    print(green + "[!] Ваш пароль -> ",password)
    print(green + "[!] Ваше устройство -> ",device_name)
    print(green + "[!] Время запуска -> ",current_time)
    r = requests.get("https://pastebin.com/u3syD3F2")
    if str(account) in r.text:
        print(green + "[!] Доступ разрешен")
        time.sleep(1)
        clear()
    else:
        print(red + "[!] Доступ запрещен, ваше устройство: " + device_name + " обратитесь к разработчику с просьбой выдать доступ!")
        colorama.Fore.RESET
        exit()

banner = green + """

     █████╗ ██████╗  █████╗ ███████╗██╗   ██╗ ██████╗███╗  ██╗ █████╗  ██████╗
    ██╔══██╗██╔══██╗██╔══██╗╚════██║╚██╗ ██╔╝██╔════╝████╗ ██║██╔══██╗██╔════╝
    ██║  ╚═╝██████╔╝███████║  ███╔═╝ ╚████╔╝ ╚█████╗ ██╔██╗██║██║  ██║╚█████╗
    ██║  ██╗██╔══██╗██╔══██║██╔══╝    ╚██╔╝   ╚═══██╗██║╚████║██║  ██║ ╚═══██╗
    ╚█████╔╝██║  ██║██║  ██║███████╗   ██║   ██████╔╝██║ ╚███║╚█████╔╝██████╔╝
     ╚════╝ ╚═╝  ╚═╝╚═╝  ╚═╝╚══════╝   ╚═╝   ╚═════╝ ╚═╝  ╚══╝ ╚════╝ ╚═════╝

   ┌───────────────────────────────────────────────────────────────────────────────┐
   │               Crack by @pr0xit.                      │
   └───────────────────────────────────────────────────────────────────────────────┘
   ┌───────────────────────────────────────────────────────────────────────────────┐
   │[1] Снос аккаунта                             [5] Бомбер входами в аккаунт     │
   │[2] Снос сессии                               [6] Сообщить об ошибке           │
   │[3] Снос ТГК                                  [7] Информация                   │
   │[4] Разбан номера                             [8] Выйти                        │
   └───────────────────────────────────────────────────────────────────────────────┘      
"""
print(banner)
choice = input(green + "[?] Введите номер желаемой функции -> ")
if choice == "1":
    clear()
    os.system("python account.py")
elif choice == "2":
    clear()
    os.system("python sessions.py")
elif choice == "3":
    clear()
    os.system("python snostgk.py")
elif choice == "4":
    clear()
    os.system("python unban.py")
elif choice == "5":
    clear()
    os.system("python bomber.py")
elif choice == "6":
    clear()
    os.system("python report.py")
elif choice == "7":
    clear()
    os.system("python info.py")
elif choice == "8":
    clear()
    print(green + "[!] Завершаю работу...")
    time.sleep(1)
    print(green + "[!] Работа завершена...")
else:
    clear()
    input(green + "[!] Ошибка, вы ввели неверное значение, нажмите ENTER для возврата в главное меню\n")
    os.system("python main.py")

