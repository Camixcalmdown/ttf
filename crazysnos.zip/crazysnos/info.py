import os
import colorama
def clear():
    os.system("clear" if os.name == "nt" else "cls")
green = colorama.Fore.LIGHTGREEN_EX
print(green + "CrazySnos - это премиум инструмент для сноса аккаунтов telegram от @Fr31zep\nв данном инструменте вы можете сносить аккаунты, сносить сессии, спамить входами в аккаунт\nОТВЕТСТВЕННОСТЬ ЗА ВАШИ ДЕЙСТВИЯ НЕСЕТЕ ИСКЛЮЧИТЕЛЬНО ВЫ")
input(green + "[!] Нажмите ENTER для возврата в главное меню\n")
clear()
os.system("python main.py")
