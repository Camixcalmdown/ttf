import webbrowser
import time
import os
import colorama
def clear():
    os.system("clear" if os.name == "nt" else "cls")
green = colorama.Fore.LIGHTGREEN_EX
print(green + "[!] Для того чтобы сообщить об ошибке напишите мне в личные сообщения telegram")
time.sleep(3)
webbrowser.open("t.me/Fr31zep")
input(green + "[!] Нажмите ENTER для возврата в главное меню\n")
clear()
os.system("python main.py")
